# The vector format, schema 1

This document is the contract every reader, validator and runner of the shared conformance corpus
implements: the home's validator and runners in this repository, and Broiler.VM's engine-level runner
over its pinned archive. A difference between two runners is never a difference in how they read a
file or render a value, because both follow this document.

## 1. Files

- A vector file has the extension `.vectors`, is UTF-8 without a byte-order mark, and uses LF line
  endings.
- A line whose first character is `#` is a comment. Comments carry no meaning.
- The first line that is not a comment reads exactly `schema: 1`.
- Records follow, separated by one or more blank lines. A record is a run of non-blank lines, each
  `key: value`: the key is everything before the first `": "`, and the value is everything after it.
- A key appears at most once in a record. An unknown key is an error.

## 2. Fields

| Key | Required | Content |
|---|---|---|
| `id` | yes | A stable identifier, unique across the corpus and never reused: lowercase letters, digits, `-` and `.`, in segments separated by `/`, the first segment the area |
| `area` | yes | One of `numbers`, `numerics`, `text`, `date`, `unicode`, `time-zones`, `intl`, `temporal`, `regexp`, `syntax`, `semantics` |
| `op` | yes | The specification operation or built-in the vector pins, for example `Number::toString` or `StringToNumber` |
| `in` | yes | The typed inputs, separated by single spaces (section 3) |
| `out` | yes | The expected outcome (section 4) |
| `class` | yes | `normative`, `impl-defined` or `divergence` (section 5) |
| `per-engine.<engine>` | for `impl-defined` | That engine's expected outcome |
| `divergence.<engine>` | for `divergence`; allowed on `impl-defined` | Why that engine is known to differ, with a link to the plan that answers it |
| `prov` | yes | Where the expected outcome comes from, as provenance entries separated by single spaces (section 6) |
| `script` | yes | One line of JavaScript source, evaluated as a Script by an engine-level runner (section 7) |
| `note` | no | Free text for a reader; it decides nothing |
| `since` | yes | The corpus revision that added the vector, a positive integer no greater than the corpus's revision ([REVISIONS.md](REVISIONS.md)) |

`<engine>` is `broiler-js` or `broiler-vm`.

## 3. Typed values

| Notation | Value |
|---|---|
| `f64:0x` and 16 uppercase hexadecimal digits | A Number, by its IEEE 754 bit pattern. **Every NaN is written `f64:0x7FF8000000000000`.** A double is never written in decimal, so no vector depends on a decimal formatter, the one under test included |
| `str:"…"` | A String, as UTF-16 code units: a code unit from U+0020 to U+007E is written as itself, except `"` written `\"` and `\` written `\\`; every other code unit, lone surrogates included, is written `\u` and four uppercase hexadecimal digits. There is exactly one way to write each string |
| `bigint:` and a decimal integer, optionally `-` | A BigInt |
| `int:` and a decimal integer, optionally `-` | An integral Number given by its value (inputs only, for arguments such as a radix) |
| `bool:true`, `bool:false` | A Boolean |
| `undefined`, `null` | Those values |
| `symbol`, `object` | A Symbol or an object (outcomes only; no identity is pinned) |

## 4. Outcomes

An outcome is one of:

- `value: <typed value>`, the value a script's evaluation completes with;
- `error: <Name>`, a thrown error object whose constructor is the named standard error: `Error`,
  `EvalError`, `RangeError`, `ReferenceError`, `SyntaxError`, `TypeError`, `URIError` or
  `AggregateError`. An early error of the script is `error: SyntaxError`;
- `throw: <typed value>`, a thrown value that is not an error object;
- `status: <word>`, a library-level status (library runners only, for example `not-implemented`).

**An engine-level runner skips a vector whose `out` is a status**: it does not evaluate the vector's script, whose
text states the computation for a reader, and its report gives the vector no line; a library-level runner gives the
vector its verdict. *(Added 2026-11-01, at corpus revision 31, when the regular-expression area's `budget.vectors`
added the corpus's first vectors whose `out` is a status, `status: exhausted`, which decision D25 of Broiler.VM's
JSD-0081 makes library-level. Until then the bullet above, "a library-level status (library runners only, for example
`not-implemented`)", was the whole rule, and neither engine-level runner skips such a vector at that revision:
Broiler.JS's, `Broiler.JS/Broiler.JavaScript.Vectors.Tests` (`EngineRunTests`, which runs every record of the corpus),
and Broiler.VM's, `VectorsCommand` of its conformance composition (at its `83290f9`, which evaluates every record it
reads), each evaluate the script, compare the outcome with the status, which no outcome matches, and report a
difference nothing classifies. Neither runner skips them yet, and no task of SJL-11's plan changes either: the skip
is a code change of each runner, with a test that a status vector gives no line, and it comes before that runner runs
revision 31. Broiler.JS's (`CorpusRun` and `EngineRunTests`) comes before revision 31 merges, or in the same change
as the classification of its first runs (revision 32), since the `engine vectors` job of `.github/workflows/ci.yml`
runs `EngineRunTests` on any change to `conformance/vectors/` and fails on a difference nothing classifies, and no
`divergence.broiler-js` field (section 5) can classify a status; Broiler.VM's (`VectorsCommand`) comes before its pin
moves to revision 31 (rule N13). Until a runner skips them, what it reports for them is no difference of the
engine's.)* *(Revised 2026-11-01, at `d8cb8406`, whose corpus is revision 31, before revision 32 classifies it: both
engine-level runners now skip them. Broiler.JS's `CorpusRun`, which `EngineRunTests` runs, skips every vector whose
`out` is a status before any is evaluated, gives it no result and so no report line, and counts and names each one in
the run's summary line, which the `engine vectors` job prints; Broiler.VM's `VectorsCommand` does the same in its
change for SJL-11.3 (its branch `sjl-11-3-vm`, which REVISIONS.md row 32 names), before its pin moves past revision
30. Each skip came with a test that a status vector is skipped, counted and named, watched failing first. So the
note's sentences "Neither runner skips them yet, and no task of SJL-11's plan changes either: the skip is a code
change of each runner, with a test that a status vector gives no line, and it comes before that runner runs revision
31" and "Until a runner skips them, what it reports for them is no difference of the engine's" describe revision 31
before `d8cb8406` only; the rule in bold above is unchanged.)*

**`out` may list alternatives**, separated by ` | `, when the specification admits more than one
result and enumerates them: the least significant digit of Number::toString, which is "not
necessarily uniquely determined", and RoundMVResult's two options beyond 20 significant digits are
the cases in the number area. A result matches the vector when it equals any alternative. A note
names the recommended alternative where the specification recommends one.

**An `impl-defined` vector that a filed owner decision classes because the specification's text gives no
well-formed result may list, as `out`'s alternatives, the engines' answers that decision records**, since it has no
ideal outcome to hold; each `per-engine` field still holds that engine's own, and the note cites the decision. *(Added
2026-11-01, at corpus revision 31, for row M4's empty match from a lastIndex inside a surrogate pair, which decision
D41 of Broiler.VM's JSD-0081 classes implementation-defined until the specification is corrected: RegExpBuiltinExec
builds a Match Record whose start passes its end, which GetMatchString's assertion forbids. Until then the paragraph
above, alternatives "when the specification admits more than one result and enumerates them", and section 5's
"`out` holds the ideal outcome" were the whole rule.)*

## 5. Classes

- **`normative`**: the specification determines the outcome, up to the alternatives `out` lists.
  Every engine is compared with `out`.
- **`impl-defined`**: the specification leaves the outcome to the implementation (for example an
  "implementation-approximated" result). `out` holds the ideal outcome, and each
  `per-engine.<engine>` field holds what that engine's own plan commits it to. **No per-engine
  expectation is ever observed from the engine**: it comes from the engine's plan, and the vector's
  note or provenance says which. An engine with no `per-engine` field is compared with `out`.
- **`divergence`**: the specification determines the outcome in `out`, and an engine is known to
  differ. Each `divergence.<engine>` field names one such engine, with the reason and a link to the
  plan that answers it. A divergence is a classified difference, not an expected value: the engine is
  still compared with `out`.

**An `impl-defined` vector may carry a `divergence.<engine>` field too**, when that engine is known
not to meet the expectation its own `per-engine.<engine>` field holds: the plan commits the engine to
it, and the engine does not do it yet. The field needs that `per-engine` field beside it, and it
classifies the difference exactly as on a `divergence` vector; the vector stays `impl-defined`,
because the specification still leaves its outcome to the implementation. *(Added 2026-10-12, at
corpus revision 3, after Broiler.VM's first run found the case; until then the field was allowed on
`divergence` vectors only.)*

**Such a field may classify a host**, when the engine's plan commits it to its `per-engine.<engine>` expectation only
on a host that provides what the expectation needs, and the engine's record is a policy of the engine that no task
changes: the field then names the hosts that lack it, what the engine answers there, and that record in the place of
the plan that answers it, as a `divergence` vector's field may name the engine policy its record keeps (revision 30's
field for row T18's `m` suffix). The field classifies any differing outcome on every host (section 8), so on a host
that provides what the expectation needs a match is reported as the divergence no longer holding, and a later
difference there would be classified too: the vector's leaving that report is what shows it, and the revision that
retires the engine's other fields on such vectors reads these again. *(Added 2026-11-04, at corpus revision 35, for
the Intl vectors whose Broiler.JS expectation is one of decision D5's extra locales' own answer, which Broiler.JS gives
only where the host's ICU lists a culture for the locale, since its available locales are the host's cultures
(decision D7 of Broiler.VM's JSD-0082, as the owner kept it that day). Until then the paragraph above was the whole
rule for an `impl-defined` vector: "the plan commits the engine to it, and the engine does not do it yet", and a
divergence field held "a link to the plan that answers it".)*

A vector an engine fails is never deleted or reclassified to make it pass. A classification change
is a dated entry in [REVISIONS.md](REVISIONS.md), in a new corpus revision.

## 6. Provenance

| Entry | Meaning |
|---|---|
| `spec:<edition>@<revision>#<clause-id>` | A clause of a pinned specification: ECMA-262 ([sources/ecma262.pin](sources/ecma262.pin)), or, when the edition is `ecma402`, ECMA-402 ([sources/ecma402.pin](sources/ecma402.pin)). The revision is 7 to 40 lower-case hexadecimal digits of that pin's commit |
| `test262:<path>` | A test of the pinned test262 revision that asserts the outcome |
| `ref:<generator>@<version>` | An independent computation in exact arithmetic, by a generator in `scripts/conformance/` |
| `ucd:<version>/<file>` | A file of the pinned Unicode Character Database ([sources/unicode.pin](sources/unicode.pin)) |
| `observed:<engine>` | An engine was seen to produce the outcome |
| `proposal:<proposal>@<revision>#<clause-id>` | A clause of a pinned TC39 proposal's specification text, for an operation the pinned edition does not contain: `temporal` ([sources/temporal.pin](sources/temporal.pin)) and `intl-era-monthcode` ([sources/intl-era-monthcode.pin](sources/intl-era-monthcode.pin)). The revision is 7 to 40 lower-case hexadecimal digits of the pinned commit, and the clause id is written as a `spec:` entry's is |
| `overruled:<generator>@<version>=<outcome>` | The answer of a reference computation that the vector **does not** take, because a recorded decision rules against it there: the outcome as section 4 writes it with the space after its kind removed (`value:str:"P1Y"`, `error:RangeError`), so it may hold no other space. It is a record, not a source of the expected value |

A clause id is the clause's id in the pinned edition's HTML: lower-case letters, digits, `.`, `-` and
`%`, which the ids of the intrinsics' clauses hold, such as `sec-%typedarray%.prototype.slice`.
*(Added 2026-10-14, at corpus revision 11. Until then the validator held a clause id to lower-case
letters, digits, `.` and `-`, and refused revision 10's citations of four such clauses.)*

**ECMA-402's clause ids may hold upper-case letters**, as `sec-Intl.DisplayNames.prototype.of` and
`sec-PartitionRelativeTimePattern` do, and a clause id of any edition is written as the pinned text's HTML writes it:
letters of either case, digits, `.`, `-` and `%`. *(Added 2026-10-26, at corpus revision 27, for the Intl area, with
the edition `ecma402` and [sources/ecma402.pin](sources/ecma402.pin). Until then the `spec:` row read "A clause of the
pinned specification ([sources/ecma262.pin](sources/ecma262.pin))", and the paragraph above, which still holds for
ECMA-262's ids, was the whole rule: "lower-case letters, digits, `.`, `-` and `%`". The validator refused ECMA-402's
ids that hold an upper-case letter, and held every `spec:` entry to ECMA-262's revision.)*

**A vector's outcome must have a source independent of both engines**: at least one entry that is not
`observed:` or `overruled:`. The validator refuses a vector whose provenance is only engine-observed, and one whose
provenance names no source at all.

*(Added 2026-10-18, at corpus revision 24, for the Temporal area: the `proposal:` and `overruled:` entries, and the
second refusal, `no-source`, with its negative control. Temporal is not in the pinned ECMA-262 edition, so its
vectors cite the pinned proposal's text by `proposal:`; their reference computation is the proposal's own polyfill
(`ref:temporalref@1`), and where the pinned text and the polyfill disagree the vector takes the text's answer under
decision D7 of bundle sjl-10-001 and records the polyfill's as `overruled:temporalref@1=<outcome>`. Until then the
section listed five kinds, and its paragraph above read "at least one entry that is not `observed:`. The validator
refuses a vector whose provenance is only engine-observed.")*

## 7. Engine-level evaluation and the rendering rule

An engine-level runner evaluates each vector in **a fresh realm**:

1. It evaluates [`prelude.js`](prelude.js) as a Script in the realm.
2. It evaluates the vector's `script` as a separate Script, sloppy unless the script's own directive
   prologue makes it strict.
3. It renders the outcome:
   - a normal completion with value V is `value: ` followed by V in the notation of section 3, with
     every NaN as `f64:0x7FF8000000000000`, -0 as `f64:0x8000000000000000`, any symbol as `symbol` and
     any object, functions and arrays included, as `object`;
   - a thrown error object, an object with an [[ErrorData]] internal slot, is `error: ` followed by
     the `name` of its constructor;
   - any other thrown value V is `throw: ` followed by V rendered as above;
   - a script the engine refuses to parse is `error: SyntaxError`;
   - an evaluation the engine does not complete, because a host exception escaped it or because it
     was still running at the runner's time limit, is `abort: ` and a description on one line. It is
     the engine's result: it matches no outcome, and a `divergence` field may classify it;
   - a fault of the runner itself (the prelude failed, a value has no rendering) is `fault: ` and a
     description on one line. It matches no outcome, and nothing classifies it.

A runner's time limit is far above the time any vector takes to complete, so that only an evaluation
that does not terminate reaches it; the runner states its limit.

The runner renders from the engine's own value representation, in the runner's code: a Number by
its bit pattern, a String by its code units. **It never asks the engine to format the value**, so a
vector's outcome does not pass through the conversion it may be testing.

A runner's report lists, for each vector: its identifier, its class, the expected outcome (the
engine's `per-engine` field for an `impl-defined` vector naming it, otherwise `out`), the rendered
outcome, and whether they match. Line endings in a rendered outcome are normalised to LF; nothing
else is normalised.

## 8. Comparison

For a running engine E, a vector's verdict is one of:

| Verdict | When |
|---|---|
| `match` | The rendered outcome equals an alternative of the expected outcome |
| `classified-divergence` | It differs, and the vector carries a `divergence.E` field (a `divergence` vector, or an `impl-defined` one, section 5) |
| `difference` | It differs, and nothing classifies the difference |

A `match` on a vector whose `divergence.E` field names E means the divergence no longer holds; the report says so,
and the next corpus revision may retire the field by a dated entry.
